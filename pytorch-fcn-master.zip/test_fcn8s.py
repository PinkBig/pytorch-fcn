# -*- coding: utf-8 -*-
# @Time : 2020/5/28/028 15:26
# @Author : Cherry_P
# @FileName: test_fcn8s.py
# @Software: PyCharm
import torch
from PIL import Image
from torchvision import transforms
import matplotlib.pyplot as plt
import numpy as np

# import myVGG
# model = myVGG.vgg16(pretrained=True)
#model = torch.hub.load('pytorch/vision:v0.6.0', 'vgg16', pretrained=True)

import fcn8s
model_path = r"D:\kaikeba___\week2_FCN\fcn8s_from_caffe.pth"
model = fcn8s.fcn8s(pretrained=True,model_path=model_path)
#model = torch.hub.load('pytorch/vision:v0.6.0', 'resnet152', pretrained=True)
model.eval()
print(model.eval())

image_path = r"D:\kaikeba___\jiwawa.jpg"
input_image = Image.open(image_path).convert('RGB')
input_image = Image.open(image_path)
print("s",input_image.size)

# ###也可以用cv.imread()  再转化为RGB
#
preprocess = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
])
input_tensor = preprocess(input_image)
print("input_tensor:",input_tensor.shape)
input_batch =input_tensor.unsqueeze(0)
print("input_batch:",input_batch.size)
if torch.cuda.is_available():
    input_batch = input_batch.to('cuda')
    model.to('cuda')

with torch.no_grad():
    output = model(input_batch)

print("output.shape",output.shape)
output = output.data[0,:]
print("output.shape",output.shape)
print(output[1,:])
for i in range(0,output.shape[0]) :
    plt.imshow(output[i, :])
    plt.savefig('D:/kaikeba___/week2_FCN/pytorch-fcn-master/21/%d.jpg'%(i+1))
    plt.close()
# plt.imshow(output[8, :])
# plt.show()
pro = torch.argmax(output.squeeze(), dim=0).detach().cpu().numpy()
print("pro",pro)
# 标签中每个RGB颜色的值
VOC_COLORMAP = [[0, 0, 0], [128, 0, 0], [0, 128, 0], [128, 128, 0],
                [0, 0, 128], [128, 0, 128], [0, 128, 128], [128, 128, 128],
                [64, 0, 0], [192, 0, 0], [64, 128, 0], [192, 128, 0],
                [64, 0, 128], [192, 0, 128], [64, 128, 128], [192, 128, 128],
                [0, 64, 0], [128, 64, 0], [0, 192, 0], [128, 192, 0],
                [0, 64, 128]]
# 标签其标注的类别
VOC_CLASSES = ['background', 'aeroplane', 'bicycle', 'bird', 'boat',
               'bottle', 'bus', 'car', 'cat', 'chair', 'cow',
               'diningtable', 'dog', 'horse', 'motorbike', 'person',
               'potted plant', 'sheep', 'sofa', 'train', 'tv/monitor']


# # print("pro_rgb",pro.shape)
# plt.subplot(121)
# plt.imshow(input_image)
# plt.title('original image')
# plt.subplot(122)
# plt.imshow(pro)
# plt.title('Seg image')
# plt.show()

